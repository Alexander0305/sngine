<?php

// set system name
define('SYS_NAME', 'Sngine');

// set system version
define('SYS_VER', '3.8');

// set api version
define('API_VER', '1.0');
